package com.example.recipeapp

import com.google.gson.annotations.SerializedName


class  Recipe(){

    ///var data: List<datum>? = null

class datum(
    @SerializedName("title") var title: String?,
    @SerializedName("author") var author: String?,
    @SerializedName("ingredients") var ingredients: String?,
    @SerializedName("instructions") var instructions: String?
) {

    @SerializedName("pk")
    var pk: Int? = null


}



}