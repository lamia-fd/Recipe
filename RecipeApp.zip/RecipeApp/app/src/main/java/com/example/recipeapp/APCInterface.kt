package com.example.recipeapp

import com.example.recipeapp.Recipe.datum
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.POST




interface APCInterface {
    @Headers("Content-Type: application/json")
    @GET("/recipes/")
    fun doGetListResources(): Call<List<datum>>
    @Headers("Content-Type: application/json")
    @POST("/recipes/")
    fun addRecipe(@Body recipes: datum): Call<Recipe>
}