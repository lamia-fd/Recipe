package com.example.recipeapp

import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.recipeapp.Recipe.datum
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        val title = findViewById<EditText>(R.id.editTextTextPersonName2)
        val author = findViewById<EditText>(R.id.editTextTextPersonName3)
        val inge = findViewById<EditText>(R.id.editTextTextPersonName4)
        val ins = findViewById<EditText>(R.id.editTextTextPersonName5)
        val savebtn = findViewById<Button>(R.id.button)

        savebtn.setOnClickListener {
            var f = datum(title.text.toString(), author.text.toString(),
                inge.text.toString(),    ins.text.toString())

            addReceipe(f, onResult = {
                title.setText("")
                author.setText("")
                inge.setText("")
                ins.setText("")
                Toast.makeText(applicationContext, "Save Success!", Toast.LENGTH_SHORT).show();
            })
        }
    }

    fun addReceipe(userData: datum, onResult: (Recipe?) -> Unit) {
        val apiInterface = APIClient().getClient()?.create(APCInterface::class.java)

        val progressDialog = ProgressDialog(this@MainActivity2)
        progressDialog.setMessage("Please wait")
        progressDialog.show()

        if (apiInterface != null) {
            apiInterface.addRecipe(userData).enqueue(object : Callback<Recipe> {
                override fun onResponse(
                    call: Call<Recipe>,
                    response: Response<Recipe>
                ) {
                    onResult(response.body())
                    progressDialog.dismiss()
                }

                override fun onFailure(call: Call<Recipe>, t: Throwable) {
                    onResult(null)
                    Toast.makeText(applicationContext, "Error!", Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss()

                }
            })
        }
    }

    fun viewreceipe(view: android.view.View) {
        intent = Intent(applicationContext, MainActivity::class.java)
        startActivity(intent)
    }
}