package com.example.recipeapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.recipeapp.Recipe.datum
import retrofit2.Call
import retrofit2.Response
import retrofit2.Callback
import java.util.*
import kotlin.collections.ArrayList


class MainActivity : AppCompatActivity() {

     var newRecipe=ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val rv=findViewById<RecyclerView>(R.id.rvMain)
       /// var tv = findViewById<TextView>(R.id.tv)
        rv.adapter= recycler(newRecipe)
        rv.layoutManager= LinearLayoutManager(this)

        val apiInterface = APIClient().getClient()?.create(APCInterface::class.java)


        if (apiInterface != null) {
            apiInterface.doGetListResources()?.enqueue(object : Callback<List<datum>> {

                override fun onResponse(
                    call: Call<List<datum>>,
                    response: Response<List<datum>>
                ) {
                    // val resource: List<Recipe.datum>? =response.body()
                    // var datumList=resource?
                    var displayResponse = ""



                    for (datum in response.body()!!) {
                        Log.d("responseBody","${datum.author} ${newRecipe.size}")
                        displayResponse = """${datum.pk} ${datum.author} ${datum.title} ${datum.ingredients} ${datum.instructions}"""
                        newRecipe.add(displayResponse)
                        rv.adapter?.notifyDataSetChanged()
                       // tv.text = displayResponse



                    }
                    rv.scrollToPosition(newRecipe.size-1)
                }

                override fun onFailure(call: Call<List<datum>?>, t: Throwable?) {
                    call.cancel()
                }


            })
        }

///////////////////////////////
        /*  apiInterface?.addrecipe(recipe("title","author","ingredients","instruction"))?.enqueue(object : Callback<recipe> {
              override fun onResponse(call: Call<recipe>, response: Response<recipe>) {

                      Toast.makeText(this@MainActivity,"Recipe Added",Toast.LENGTH_LONG).show()

              }

              override fun onFailure(call: Call<recipe>, t: Throwable) {

                  Toast.makeText(applicationContext, ""+t.message, Toast.LENGTH_SHORT).show()
              }


          })*/
        /////////////


    }


    fun adduser(view: android.view.View) {

        intent = Intent(applicationContext, MainActivity2::class.java)
        startActivity(intent)

    }

}


